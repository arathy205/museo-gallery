
document.addEventListener('DOMContentLoaded', () => {
  // Stagger in cards
  document.querySelectorAll('.stagger .card').forEach((card, i) => {
    card.style.animationDelay = (i * 120) + 'ms';
    card.classList.add('fade-slide-up');
  });

  // Back to top
  const btns = document.querySelectorAll('.back-to-top');
  btns.forEach(btn => btn.addEventListener('click', (e) => {
    e.preventDefault();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }));
});
