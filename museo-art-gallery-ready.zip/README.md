
# Museo — Mini Art Gallery (Bootstrap)

A simple 9-page static site built with HTML, CSS, and Bootstrap. It includes:
- Login page
- Sign-up page
- Gallery home (index)
- Gallery listing page (art display with images, artist names, and links)
- 5 individual artwork pages (each with image, artist name, year, short description, and similar works)

## Run locally
Just open `index.html` in your browser. No build step required.

## Deploy to GitHub Pages
1. Create a new GitHub repository (public), e.g., `museo-gallery`.
2. Upload all files in this folder to the repo (including the `assets/` directory).
3. In **Settings → Pages**, set **Build and deployment** to **Deploy from a branch**, branch `main`, folder `/ (root)` and click Save.
4. Your site will be live at `https://<your-username>.github.io/museo-gallery/` within a minute.

## Notes
- Uses Bootstrap via CDN; no form validation at this stage.
- Includes hover/entrance animations and a smooth “back to top” interaction for a bit of delight.
- Images reference public Wikimedia Commons URLs for convenience.
